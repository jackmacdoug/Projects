package compiler;

public interface RSymbol 
{
	public boolean IsToken();
	
	public boolean IsAction();
}
