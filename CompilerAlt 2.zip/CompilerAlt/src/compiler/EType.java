package compiler;

public enum EType
{ 
	ARITHMETIC, RELATIONAL;
}
