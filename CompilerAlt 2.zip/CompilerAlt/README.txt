. . . . . . . . . . . .
       COMPILER
. . . . . . . . . . . .
   BY JOHN MACDOUGALL
. . . . . . . . . . . .

1) LEXICAL ANALYZER
___________________
The Lexer returns one token at a time via the GetNextToken() function.

VALID CHARS: 
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890" +
".,;:<>/*[]+-=()}{\t ";

ERROR TYPES:
-Identifier too long or Constant (int or real) too long
-Ill-formed comment (anytime you see a ‘}’ that doesn’t end a comment
-Invalid char (if the char passed by getChar() doesn’t match any of the cases defined by readLetter(), readNumber(), and readSymbol


2) PARSER
___________________
The parser instantiates the Lexical Analyzer and calls getNextToken() until the end of file is reached.

*** To pass in any input file, simply change the FILENAME variable to the file path of your choice. ***

*** I couldn’t figure out how to implement a print flag as command line input, but the PRINT boolean at the top of the Parser class can be changed to false to avoid printing ***

ERROR TYPES:
-The lookahead token and top of stack symbol don’t match any production rules (999)
-Invalid token (I don’t think this case should ever get thrown but it’s there just in case)
-Invalid top of stack symbol